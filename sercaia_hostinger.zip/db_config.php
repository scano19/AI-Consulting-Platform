<?php
// DATABASE CONFIGURATION
// ----------------------
// EDIT THIS FILE WITH YOUR HOSTINGER DATABASE CREDENTIALS

define('DB_HOST', 'localhost'); // Usually 'localhost' on Hostinger
define('DB_NAME', 'u123456789_sercaia_db'); // CHANGE THIS to your database name
define('DB_USER', 'u123456789_user');       // CHANGE THIS to your database user
define('DB_PASS', 'YourPassword123!');      // CHANGE THIS to your database password

// Email Configuration
define('EMAIL_FROM', 'info@sercaia.com');
define('EMAIL_NAME', 'SercaIA Intelligence');
?>
